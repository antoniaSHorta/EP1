package com.mycompany.clinisync;

public class Opciones {

    public void Menu() {

        System.out.println("INGRESE LA OPCION");
        System.out.println("1. Crear Datos");
        System.out.println("2. Actualizar Datos");
        System.out.println("3. Leer Datos");
        System.out.println("4. Eliminar Datos");
        System.out.println("0. Salir sistema");
    }
}
